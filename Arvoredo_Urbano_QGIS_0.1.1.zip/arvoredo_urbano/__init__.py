def classFactory(iface):
    from .plugin import ArvoredoUrbanoPlugin
    return ArvoredoUrbanoPlugin(iface)
