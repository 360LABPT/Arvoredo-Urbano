# Arvoredo Urbano para QGIS

Plugin de inventário e gestão de árvores urbanas, em português de Portugal.
Versão de trabalho 0.1.1, destinada a instalação local em QGIS 3.34–3.x.
Ensaio funcional realizado com QGIS 3.40.6.

## Instalação

1. Em **Plugins → Gerir e instalar plugins → Instalar a partir de ZIP**, escolha `Arvoredo_Urbano_QGIS_0.1.1.zip`.
2. Ative **Arvoredo Urbano** no gestor de plugins.
3. Abra **Vetor → Arvoredo urbano** ou use o ícone da barra de ferramentas.

Para atualizar a versão 0.1.0, instale o novo ZIP no gestor de plugins e reinicie o QGIS. Se o gestor não permitir a substituição, desinstale primeiro a versão antiga no próprio gestor e instale a 0.1.1. O ficheiro `.gpkg` do inventário é independente da pasta do plugin; os inventários criados na versão anterior foram ensaiados com esta versão.

O ZIP contém uma única pasta `arvoredo_urbano` com os ficheiros do plugin. Não é necessário instalar bibliotecas Python adicionais.

## Utilização

1. Clique **Criar inventário** e escolha um ficheiro `.gpkg`. Um ficheiro existente nunca é substituído pela criação.
2. Clique **Nova árvore no mapa**, marque a posição, complete pelo menos o código e um nome da espécie, e escolha **Guardar ficha**.
3. Selecione uma linha da lista ou selecione a árvore na camada do QGIS para consultar e alterar a ficha.
4. Nas abas **Inspeções** e **Intervenções**, registe avaliações e ações. Uma inspeção atualiza o estado, risco e datas de inspeção na camada; a data de inspeção mais recente prevalece.
5. Consulte **Pendentes** para intervenções planeadas ou em curso. Um prazo vencido aparece a vermelho. Altere o estado de uma intervenção na aba correspondente.
6. Use **Exportar CSV** para obter `arvores.csv`, `inspecoes.csv` e `intervencoes.csv` em UTF-8 com separador `;`. As coordenadas exportadas são longitude e latitude em WGS 84.

As novas árvores são guardadas em ETRS89 / Portugal TM06 (EPSG:3763). O ponto marcado no mapa é transformado automaticamente a partir do SRC do projeto. A camada é colorida pela classificação de risco. Os dados persistem num único GeoPackage, que pode ser copiado para uma cópia de segurança com o QGIS fechado.

## Dados e campos

- A camada `arvores` guarda código, UUID, espécies, freguesia, local, morada, entidade de gestão, altura, DAP, diâmetro da copa, estado, risco, datas, observações e situação ativa.
- As tabelas `au_inspecoes` e `au_intervencoes` guardam o histórico associado ao UUID estável da árvore.
- Datas usam `AAAA-MM-DD`. Medidas admitem vírgula ou ponto decimal.
- A opção **Árvore presente / ativa** permite manter fichas históricas sem apagar registos.

## Limites desta versão

- O risco é uma classificação introduzida pelo utilizador; o plugin não calcula risco biomecânico nem substitui inspeção técnica.
- Os campos de inspeção e intervenção são textos livres. Não há fotografia anexada, importação de inventários externos, sincronização multiutilizador ou edição de um registo histórico após gravação. O estado das intervenções pode ser alterado.
- A edição direta da camada fora do painel é possível, mas o plugin exige que qualquer sessão de edição QGIS esteja terminada antes de gravar pelo painel. Apagar árvores diretamente na tabela de atributos pode deixar histórico sem ficha correspondente.
- A versão foi ensaiada em QGIS 3.40.6; a instalação em outras versões 3.x deve ser confirmada no ambiente de destino. Não foi validada em QGIS 4.
- O histórico é escrito através do fornecedor OGR/GeoPackage do QGIS, sem importar o módulo Python `_sqlite3`.

## Verificação de desenvolvimento

No ambiente com PyQGIS instalado:

```bash
QT_QPA_PLATFORM=offscreen PYTHONPATH=. /usr/bin/python3 arvoredo_urbano/tests/smoke.py
QT_QPA_PLATFORM=offscreen PYTHONPATH=. /usr/bin/python3 arvoredo_urbano/tests/ui_smoke.py
QT_QPA_PLATFORM=offscreen PYTHONPATH=. /usr/bin/python3 arvoredo_urbano/tests/import_without_sqlite.py
```

Execute os comandos a partir da pasta que contém `arvoredo_urbano`.
