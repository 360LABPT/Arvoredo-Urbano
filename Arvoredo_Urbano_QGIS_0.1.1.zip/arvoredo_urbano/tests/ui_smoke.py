"""Arranque do painel QGIS sem janela visível."""

import os
import tempfile

from qgis.PyQt.QtWidgets import QMainWindow
from qgis.core import QgsApplication, QgsPointXY
from qgis.gui import QgsMapCanvas

from arvoredo_urbano.plugin import ArvoredoUrbanoPlugin


class FakeInterface:
    def __init__(self):
        self.window = QMainWindow()
        self.canvas = QgsMapCanvas()

    def mainWindow(self):
        return self.window

    def mapCanvas(self):
        return self.canvas

    def addPluginToVectorMenu(self, *args):
        pass

    def removePluginVectorMenu(self, *args):
        pass

    def addToolBarIcon(self, *args):
        pass

    def removeToolBarIcon(self, *args):
        pass

    def addDockWidget(self, area, dock):
        self.window.addDockWidget(area, dock)

    def removeDockWidget(self, dock):
        self.window.removeDockWidget(dock)


app = QgsApplication([], True)
app.initQgis()
iface = FakeInterface()
plugin = ArvoredoUrbanoPlugin(iface)
plugin.initGui()
plugin.run()
with tempfile.TemporaryDirectory() as folder:
    path = os.path.join(folder, "arvores.gpkg")
    from arvoredo_urbano.storage import create_inventory
    create_inventory(path)
    dock = plugin.dock
    dock.load(path)
    dock.pending_point = QgsPointXY(150000, -120000)
    dock.tree_fields["codigo"].setText("AU-00001")
    dock.tree_fields["especie_comum"].setText("Tília")
    dock.save()
    assert dock.tree_table.rowCount() == 1
    assert dock.current_fid is not None
    dock.in_tech.setText("Técnico")
    dock.add_inspection()
    assert dock.inspections.rowCount() == 1
    dock.add_intervention()
    assert dock.actions.rowCount() == 1
    assert dock.tasks.rowCount() == 1
    print("OK: interface, ficha, inspeção e tarefa")
plugin.unload()
