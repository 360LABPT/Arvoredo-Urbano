"""Verifica o carregamento do plugin quando sqlite3 é bloqueado."""

import builtins

from qgis.core import QgsApplication


app = QgsApplication([], True)
app.initQgis()
original_import = builtins.__import__


def deny_sqlite(name, *args, **kwargs):
    if name in ("sqlite3", "_sqlite3"):
        raise ImportError("Módulo bloqueado por política de aplicações")
    return original_import(name, *args, **kwargs)


builtins.__import__ = deny_sqlite
try:
    from arvoredo_urbano import classFactory
    from arvoredo_urbano import storage

    class FakeInterface:
        pass

    assert classFactory(FakeInterface()) is not None
    assert storage.TABLE_FIELDS
    print("OK: classFactory sem sqlite3")
finally:
    builtins.__import__ = original_import
