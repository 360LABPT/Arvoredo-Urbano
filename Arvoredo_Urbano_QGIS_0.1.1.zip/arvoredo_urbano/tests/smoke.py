"""Ensaio de integração: QT_QPA_PLATFORM=offscreen /usr/bin/python3 tests/smoke.py"""

import csv
import os
import tempfile

from qgis.core import QgsApplication, QgsPointXY

from arvoredo_urbano import storage


app = QgsApplication([], False)
app.initQgis()

with tempfile.TemporaryDirectory() as folder:
    path = os.path.join(folder, "inventario.gpkg")
    storage.create_inventory(path)
    layer = storage.open_inventory(path)
    feature = storage.save_tree(layer, {
        "codigo": "AU-00001", "especie_cientifica": "Tilia cordata",
        "especie_comum": "Tília", "freguesia": "Alcácer do Sal",
        "local": "Praça", "estado": "Não avaliado", "risco": "Não avaliado",
        "ativo": 1,
    }, QgsPointXY(150000, -120000))
    assert layer.featureCount() == 1
    assert feature["uuid"]
    assert feature.geometry().asPoint().x() == 150000
    try:
        storage.save_tree(layer, {"codigo": "AU-00001", "especie_comum": "Plátano"},
                          QgsPointXY(150001, -120000))
    except ValueError as exc:
        assert "código" in str(exc)
    else:
        raise AssertionError("Aceitou um código duplicado")
    storage.add_inspection(path, layer, feature, {
        "data": "2026-11-18", "tecnico": "Técnico A", "estado": "Razoável",
        "risco": "Moderado", "defeitos": "Ramo seco", "recomendacoes": "Poda",
        "proxima_inspecao": "2027-05-18",
    })
    stored = next(layer.getFeatures())
    assert stored["risco"] == "Moderado"
    assert stored["ultima_inspecao"] == "2026-11-18"
    assert len(storage.records(path, "au_inspecoes", stored["uuid"])) == 1
    storage.add_inspection(path, layer, stored, {
        "data": "2026-01-01", "tecnico": "Técnico B", "estado": "Bom",
        "risco": "Baixo", "proxima_inspecao": "2026-07-01",
    })
    assert next(layer.getFeatures())["ultima_inspecao"] == "2026-11-18"
    storage.add_intervention(path, stored["uuid"], {
        "tipo": "Poda", "data": "2026-11-19", "estado": "Planeada",
        "prazo": "2026-12-01", "responsavel": "Equipa A",
    })
    record = storage.records(path, "au_intervencoes", stored["uuid"])[0]
    storage.update_intervention(path, record["id"], stored["uuid"], "Concluída")
    assert storage.records(path, "au_intervencoes", stored["uuid"])[0]["estado"] == "Concluída"
    edited = storage.save_tree(layer, {
        "codigo": "AU-00001", "especie_cientifica": "Tilia cordata",
        "especie_comum": "Tília", "freguesia": "Alcácer do Sal", "local": "Praça",
        "estado": "Razoável", "risco": "Moderado", "ativo": 1,
        "proxima_inspecao": "2027-05-18",
    }, fid=stored.id())
    assert edited["uuid"] == stored["uuid"]
    assert edited["ultima_inspecao"] == "2026-11-18"
    files = storage.export_csv(path, layer, folder)
    assert len(files) == 3
    with open(files[0], encoding="utf-8-sig", newline="") as inp:
        rows = list(csv.DictReader(inp, delimiter=";"))
    assert len(rows) == 1 and rows[0]["codigo"] == "AU-00001"
    assert float(rows[0]["longitude"]) < 0
    reopened = storage.open_inventory(path)
    assert reopened.featureCount() == 1
    print("OK: criação, edição, inspeção, intervenção, exportação e reabertura")
