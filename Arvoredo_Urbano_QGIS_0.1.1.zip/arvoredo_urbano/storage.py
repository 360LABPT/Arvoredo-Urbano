"""GeoPackage do inventário e histórico operacional."""

import csv
import os
import uuid
from datetime import date, datetime

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature,
    QgsField, QgsGeometry, QgsProject, QgsVectorFileWriter, QgsVectorLayer,
)


FIELDS = (
    ("uuid", QVariant.String), ("codigo", QVariant.String),
    ("especie_cientifica", QVariant.String), ("especie_comum", QVariant.String),
    ("freguesia", QVariant.String), ("local", QVariant.String),
    ("morada", QVariant.String), ("gestao", QVariant.String),
    ("altura_m", QVariant.Double), ("dap_cm", QVariant.Double),
    ("diametro_copa_m", QVariant.Double), ("estado", QVariant.String),
    ("risco", QVariant.String), ("data_plantacao", QVariant.String),
    ("ultima_inspecao", QVariant.String), ("proxima_inspecao", QVariant.String),
    ("observacoes", QVariant.String), ("ativo", QVariant.Int),
    ("criado_em", QVariant.String), ("atualizado_em", QVariant.String),
)
NAMES = [name for name, _ in FIELDS]
TABLE_FIELDS = {
    "au_inspecoes": (
        "arvore_uuid", "data", "tecnico", "estado", "risco", "defeitos",
        "recomendacoes", "proxima_inspecao", "criado_em"
    ),
    "au_intervencoes": (
        "arvore_uuid", "tipo", "data", "responsavel", "estado", "prazo",
        "notas", "criado_em"
    ),
}


def iso_date(value):
    if not value:
        return ""
    try:
        return date.fromisoformat(value.strip()).isoformat()
    except ValueError as exc:
        raise ValueError("Use datas no formato AAAA-MM-DD.") from exc


def text_value(value):
    if value is None or value == QVariant():
        return ""
    return str(value) if str(value) != "NULL" else ""


def create_inventory(path):
    if os.path.exists(path):
        raise ValueError("Já existe um ficheiro neste caminho. Escolha outro nome.")
    layer = QgsVectorLayer("Point?crs=EPSG:3763", "Árvores", "memory")
    layer.dataProvider().addAttributes([QgsField(name, kind) for name, kind in FIELDS])
    layer.updateFields()
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GPKG"
    opts.layerName = "arvores"
    opts.fileEncoding = "UTF-8"
    result = QgsVectorFileWriter.writeAsVectorFormatV3(
        layer, path, QgsProject.instance().transformContext(), opts
    )
    if result[0] != QgsVectorFileWriter.NoError:
        raise RuntimeError("Não foi possível criar o GeoPackage: " + str(result[1]))
    try:
        ensure_tables(path)
    except Exception:
        os.remove(path)
        raise


def ensure_tables(path):
    for name, fields in TABLE_FIELDS.items():
        table = QgsVectorLayer(path + "|layername=" + name, name, "ogr")
        if table.isValid():
            if not set(fields).issubset(table.fields().names()):
                raise ValueError("A tabela " + name + " não tem o esquema esperado.")
            continue
        memory = QgsVectorLayer("None", name, "memory")
        memory.dataProvider().addAttributes([QgsField(field, QVariant.String) for field in fields])
        memory.updateFields()
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = name
        opts.fileEncoding = "UTF-8"
        opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            memory, path, QgsProject.instance().transformContext(), opts
        )
        if result[0] != QgsVectorFileWriter.NoError:
            raise RuntimeError("Não foi possível criar " + name + ": " + str(result[1]))


def history_layer(path, table):
    if table not in TABLE_FIELDS:
        raise ValueError("Tabela inválida.")
    layer = QgsVectorLayer(path + "|layername=" + table, table, "ogr")
    if not layer.isValid() or not set(TABLE_FIELDS[table]).issubset(layer.fields().names()):
        raise ValueError("A tabela de histórico não está disponível: " + table)
    return layer


def _commit(layer):
    if not layer.commitChanges():
        error = "; ".join(layer.commitErrors())
        layer.rollBack()
        raise RuntimeError("Não foi possível guardar o histórico: " + error)


def _insert(path, table_name, values):
    layer = history_layer(path, table_name)
    feature = QgsFeature(layer.fields())
    for name in TABLE_FIELDS[table_name]:
        feature[name] = values.get(name, "")
    if not layer.startEditing():
        raise RuntimeError("Não foi possível iniciar a edição do histórico.")
    if not layer.addFeature(feature):
        layer.rollBack()
        raise RuntimeError("Não foi possível adicionar o registo ao histórico.")
    _commit(layer)
    matches = (f.id() for f in layer.getFeatures()
               if text_value(f["arvore_uuid"]) == values["arvore_uuid"]
               and text_value(f["criado_em"]) == values["criado_em"])
    return max(matches)


def _delete(path, table_name, record_id):
    layer = history_layer(path, table_name)
    if not layer.startEditing():
        raise RuntimeError("Não foi possível reverter o registo.")
    if not layer.deleteFeature(record_id):
        layer.rollBack()
        raise RuntimeError("Não foi possível reverter o registo.")
    _commit(layer)


def open_inventory(path):
    layer = QgsVectorLayer(path + "|layername=arvores", "Arvoredo urbano", "ogr")
    if not layer.isValid() or not set(NAMES).issubset(layer.fields().names()):
        raise ValueError("O ficheiro não contém um inventário de Arvoredo Urbano compatível.")
    ensure_tables(path)
    return layer


def save_tree(layer, values, point=None, fid=None):
    """Guarda uma ficha em transação; nunca confirma outras edições abertas."""
    if layer.isEditable():
        raise RuntimeError("Termine ou cancele as edições abertas na camada antes de guardar.")
    code = values["codigo"].strip()
    if not code:
        raise ValueError("O código da árvore é obrigatório.")
    if not values.get("especie_cientifica", "").strip() and not values.get("especie_comum", "").strip():
        raise ValueError("Indique pelo menos um nome da espécie.")
    if fid is None and point is None:
        raise ValueError("Clique no mapa para indicar a localização da nova árvore.")
    for feature in layer.getFeatures():
        if feature.id() != fid and text_value(feature["codigo"]).casefold() == code.casefold():
            raise ValueError("Este código já pertence a outra árvore.")
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    old = None
    if fid is not None:
        old = layer.getFeature(fid)
        if not old.isValid():
            raise ValueError("A árvore selecionada deixou de existir.")
    data = {name: (values[name] if name in values else
                   old[name] if old is not None else
                   None if name in ("altura_m", "dap_cm", "diametro_copa_m") else
                   1 if name == "ativo" else "")
            for name in NAMES}
    data["codigo"] = code
    data["atualizado_em"] = now
    if fid is None:
        data["uuid"] = str(uuid.uuid4())
        data["criado_em"] = now
        feature = QgsFeature(layer.fields())
        for name in NAMES:
            feature[name] = data[name]
        feature.setGeometry(QgsGeometry.fromPointXY(point))
    else:
        data["uuid"] = old["uuid"]
        data["criado_em"] = old["criado_em"]
    if not layer.startEditing():
        raise RuntimeError("Não foi possível iniciar a edição da camada.")
    try:
        if fid is None:
            if not layer.addFeature(feature):
                raise RuntimeError("Não foi possível acrescentar a árvore.")
        else:
            for name in NAMES:
                if not layer.changeAttributeValue(fid, layer.fields().indexOf(name), data[name]):
                    raise RuntimeError("Não foi possível alterar o campo " + name)
            if point is not None and not layer.changeGeometry(fid, QgsGeometry.fromPointXY(point)):
                raise RuntimeError("Não foi possível alterar a localização.")
        if not layer.commitChanges():
            raise RuntimeError("Erro ao guardar: " + "; ".join(layer.commitErrors()))
    except Exception:
        if layer.isEditable():
            layer.rollBack()
        raise
    # O provider pode atribuir um novo FID no commit; o UUID é a chave estável.
    for stored in layer.getFeatures():
        if text_value(stored["uuid"]) == data["uuid"]:
            return stored
    raise RuntimeError("A árvore foi guardada, mas não foi possível voltar a localizá-la.")


def records(path, table, tree_uuid):
    result = [record for record in all_records(path, table)
              if record["arvore_uuid"] == tree_uuid]
    return sorted(result, key=lambda r: (r["data"], r["id"]), reverse=True)


def all_records(path, table):
    layer = history_layer(path, table)
    return [{"id": feature.id(), **{name: text_value(feature[name])
                                     for name in TABLE_FIELDS[table]}}
            for feature in layer.getFeatures()]


def add_inspection(path, layer, feature, data):
    if layer.isEditable():
        raise RuntimeError("Termine ou cancele as edições abertas na camada antes da inspeção.")
    when = iso_date(data.get("data", ""))
    if not when or not data.get("tecnico", "").strip():
        raise ValueError("A data e o técnico são obrigatórios.")
    next_date = iso_date(data.get("proxima_inspecao", ""))
    uuid_value = text_value(feature["uuid"])
    if not uuid_value:
        raise ValueError("A árvore não tem identificador.")
    now = datetime.now().astimezone().isoformat(timespec="microseconds")
    new_id = _insert(path, "au_inspecoes", {
        "arvore_uuid": uuid_value, "data": when, "tecnico": data["tecnico"].strip(),
        "estado": data.get("estado", ""), "risco": data.get("risco", ""),
        "defeitos": data.get("defeitos", ""),
        "recomendacoes": data.get("recomendacoes", ""),
        "proxima_inspecao": next_date, "criado_em": now,
    })
    latest = records(path, "au_inspecoes", uuid_value)[0]
    updates = {"ultima_inspecao": latest["data"], "estado": latest["estado"],
               "risco": latest["risco"], "proxima_inspecao": latest["proxima_inspecao"],
               "atualizado_em": now}
    try:
        if not layer.startEditing():
            raise RuntimeError("Não foi possível editar a ficha da árvore.")
        for name, value in updates.items():
            if not layer.changeAttributeValue(feature.id(), layer.fields().indexOf(name), value):
                raise RuntimeError("Não foi possível atualizar " + name)
        if not layer.commitChanges():
            raise RuntimeError("Erro ao atualizar a ficha: " + "; ".join(layer.commitErrors()))
    except Exception:
        if layer.isEditable():
            layer.rollBack()
        _delete(path, "au_inspecoes", new_id)
        raise


def add_intervention(path, tree_uuid, data):
    when = iso_date(data.get("data", ""))
    deadline = iso_date(data.get("prazo", ""))
    if not when or not data.get("tipo", "").strip():
        raise ValueError("A data e o tipo de intervenção são obrigatórios.")
    _insert(path, "au_intervencoes", {
        "arvore_uuid": tree_uuid, "tipo": data["tipo"].strip(), "data": when,
        "responsavel": data.get("responsavel", ""),
        "estado": data.get("estado", "Planeada"), "prazo": deadline,
        "notas": data.get("notas", ""),
        "criado_em": datetime.now().astimezone().isoformat(timespec="microseconds"),
    })


def update_intervention(path, record_id, tree_uuid, status):
    if status not in ("Planeada", "Em curso", "Concluída", "Cancelada"):
        raise ValueError("Estado inválido.")
    layer = history_layer(path, "au_intervencoes")
    feature = layer.getFeature(record_id)
    if not feature.isValid() or text_value(feature["arvore_uuid"]) != tree_uuid:
        raise ValueError("A intervenção já não está disponível.")
    if not layer.startEditing():
        raise RuntimeError("Não foi possível editar a intervenção.")
    if not layer.changeAttributeValue(record_id, layer.fields().indexOf("estado"), status):
        layer.rollBack()
        raise RuntimeError("Não foi possível alterar o estado.")
    _commit(layer)


def pending_interventions(path):
    result = [record for record in all_records(path, "au_intervencoes")
              if record["estado"] in ("Planeada", "Em curso")]
    return sorted(result, key=lambda r: (not bool(r["prazo"]), r["prazo"], r["id"]))


def export_csv(path, layer, directory):
    targets = [os.path.join(directory, item + ".csv") for item in
               ("arvores", "inspecoes", "intervencoes")]
    with open(targets[0], "w", encoding="utf-8-sig", newline="") as out:
        writer = csv.writer(out, delimiter=";")
        writer.writerow(NAMES + ["longitude", "latitude"])
        transform = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
                                           QgsProject.instance())
        for feature in layer.getFeatures():
            p = transform.transform(feature.geometry().asPoint())
            writer.writerow([text_value(feature[name]) for name in NAMES] + [p.x(), p.y()])
    for table, target in (("au_inspecoes", targets[1]), ("au_intervencoes", targets[2])):
        with open(target, "w", encoding="utf-8-sig", newline="") as out:
            writer = csv.writer(out, delimiter=";")
            writer.writerow(["id", *TABLE_FIELDS[table]])
            for record in sorted(all_records(path, table), key=lambda r: r["id"]):
                writer.writerow([record["id"], *(record[name] for name in TABLE_FIELDS[table])])
    return targets
