"""Painel QGIS para inventário e manutenção de arvoredo urbano."""

import os
from datetime import date

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtWidgets import (
    QAction, QCheckBox, QComboBox, QDockWidget, QFileDialog,
    QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton,
    QScrollArea, QTabWidget, QTableWidget, QTableWidgetItem, QTextEdit,
    QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsCategorizedSymbolRenderer, QgsCoordinateTransform, QgsMarkerSymbol,
    QgsProject, QgsRendererCategory,
)
from qgis.gui import QgsMapToolEmitPoint

from . import storage


RISKS = ("Não avaliado", "Baixo", "Moderado", "Alto", "Urgente")
CONDITIONS = ("Não avaliado", "Bom", "Razoável", "Mau", "Morto")
STATUSES = ("Planeada", "Em curso", "Concluída", "Cancelada")


def field_text(feature, name):
    return storage.text_value(feature[name])


def cell(value):
    item = QTableWidgetItem(str(value or ""))
    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
    return item


class ArvoredoDock(QDockWidget):
    def __init__(self, plugin):
        super().__init__("Arvoredo urbano", plugin.iface.mainWindow())
        self.plugin = plugin
        self.layer = None
        self.path = None
        self.current_fid = None
        self.pending_point = None
        self._loading = False
        self.dirty = False
        self.setObjectName("ArvoredoUrbanoDock")
        self.setMinimumWidth(420)
        body = QWidget()
        root = QVBoxLayout(body)
        self.setWidget(body)

        controls = QHBoxLayout()
        for title, fn in (("Criar inventário", self.create_file),
                          ("Abrir", self.open_file), ("Exportar CSV", self.export)):
            button = QPushButton(title)
            button.clicked.connect(fn)
            controls.addWidget(button)
        root.addLayout(controls)
        self.file_label = QLabel("Abra ou crie um inventário GeoPackage.")
        self.file_label.setWordWrap(True)
        root.addWidget(self.file_label)

        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Código, espécie, local ou freguesia")
        self.search.textChanged.connect(self.refresh_list)
        filters.addWidget(self.search)
        self.risk_filter = QComboBox()
        self.risk_filter.addItems(("Todos os riscos",) + RISKS)
        self.risk_filter.currentTextChanged.connect(self.refresh_list)
        filters.addWidget(self.risk_filter)
        root.addLayout(filters)

        self.tree_table = QTableWidget(0, 5)
        self.tree_table.setHorizontalHeaderLabels(
            ["Código", "Espécie", "Freguesia", "Estado", "Risco"])
        self.tree_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.tree_table.setSelectionMode(QTableWidget.SingleSelection)
        self.tree_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tree_table.verticalHeader().hide()
        self.tree_table.cellClicked.connect(self.choose_row)
        root.addWidget(self.tree_table, 2)
        self.count_label = QLabel("0 árvores")
        root.addWidget(self.count_label)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 3)
        self._build_tree_tab()
        self._build_inspection_tab()
        self._build_intervention_tab()
        self._build_tasks_tab()
        self._clear_form()

    def _text(self, form, label, key, placeholder=""):
        widget = QLineEdit()
        widget.setPlaceholderText(placeholder)
        form.addRow(label, widget)
        self.tree_fields[key] = widget
        widget.textChanged.connect(self._mark_dirty)
        return widget

    def _combo(self, form, label, key, choices):
        widget = QComboBox()
        widget.addItems(choices)
        form.addRow(label, widget)
        self.tree_fields[key] = widget
        widget.currentTextChanged.connect(self._mark_dirty)
        return widget

    def _build_tree_tab(self):
        tab = QWidget()
        outer = QVBoxLayout(tab)
        buttons = QHBoxLayout()
        for title, fn in (("Nova árvore no mapa", self.new_tree),
                          ("Mover no mapa", self.move_tree),
                          ("Guardar ficha", self.save)):
            button = QPushButton(title)
            button.clicked.connect(fn)
            buttons.addWidget(button)
        outer.addLayout(buttons)
        self.position_label = QLabel("Selecione uma árvore ou marque um ponto no mapa.")
        self.position_label.setWordWrap(True)
        outer.addWidget(self.position_label)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        form_widget = QWidget()
        form = QFormLayout(form_widget)
        scroll.setWidget(form_widget)
        outer.addWidget(scroll)
        self.tree_fields = {}
        self._text(form, "Código *", "codigo", "Ex.: AS-0001")
        self._text(form, "Espécie científica", "especie_cientifica")
        self._text(form, "Nome comum", "especie_comum")
        self._text(form, "Freguesia", "freguesia")
        self._text(form, "Local / arruamento", "local")
        self._text(form, "Morada / referência", "morada")
        self._combo(form, "Gestão", "gestao", ("Municipal", "Outra", "Por confirmar"))
        for label, key in (("Altura (m)", "altura_m"), ("DAP (cm)", "dap_cm"),
                           ("Diâmetro da copa (m)", "diametro_copa_m")):
            self._text(form, label, key, "Número; pode usar vírgula")
        self._combo(form, "Estado", "estado", CONDITIONS)
        self._combo(form, "Risco", "risco", RISKS)
        self._text(form, "Data de plantação", "data_plantacao", "AAAA-MM-DD, se conhecida")
        self._text(form, "Próxima inspeção", "proxima_inspecao", "AAAA-MM-DD")
        self.notes = QTextEdit()
        self.notes.setMaximumHeight(90)
        self.notes.textChanged.connect(self._mark_dirty)
        form.addRow("Observações", self.notes)
        self.active = QCheckBox("Árvore presente / ativa")
        self.active.toggled.connect(self._mark_dirty)
        form.addRow("Situação", self.active)
        self.tabs.addTab(tab, "Ficha")

    def _build_inspection_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form = QFormLayout()
        self.in_date = QLineEdit(date.today().isoformat())
        self.in_tech = QLineEdit()
        self.in_state = QComboBox()
        self.in_state.addItems(CONDITIONS)
        self.in_risk = QComboBox()
        self.in_risk.addItems(RISKS)
        self.in_defects = QTextEdit()
        self.in_recommend = QTextEdit()
        self.in_next = QLineEdit()
        self.in_next.setPlaceholderText("AAAA-MM-DD")
        for label, widget in (("Data *", self.in_date), ("Técnico *", self.in_tech),
                              ("Estado", self.in_state), ("Risco", self.in_risk),
                              ("Defeitos observados", self.in_defects),
                              ("Recomendações", self.in_recommend),
                              ("Próxima inspeção", self.in_next)):
            form.addRow(label, widget)
        layout.addLayout(form)
        button = QPushButton("Registar inspeção")
        button.clicked.connect(self.add_inspection)
        layout.addWidget(button)
        self.inspections = QTableWidget(0, 4)
        self.inspections.setHorizontalHeaderLabels(["Data", "Técnico", "Estado", "Risco"])
        self.inspections.setEditTriggers(QTableWidget.NoEditTriggers)
        self.inspections.cellClicked.connect(self.show_inspection_detail)
        layout.addWidget(self.inspections)
        self.inspection_detail = QLabel("Selecione uma inspeção para ver os detalhes.")
        self.inspection_detail.setWordWrap(True)
        layout.addWidget(self.inspection_detail)
        self.tabs.addTab(tab, "Inspeções")

    def _build_intervention_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form = QFormLayout()
        self.ac_type = QComboBox()
        self.ac_type.setEditable(True)
        self.ac_type.addItems(("Poda", "Rega", "Tratamento", "Tutoragem", "Abate", "Plantação", "Outra"))
        self.ac_date = QLineEdit(date.today().isoformat())
        self.ac_person = QLineEdit()
        self.ac_status = QComboBox()
        self.ac_status.addItems(STATUSES)
        self.ac_deadline = QLineEdit()
        self.ac_deadline.setPlaceholderText("AAAA-MM-DD")
        self.ac_notes = QTextEdit()
        for label, widget in (("Tipo *", self.ac_type), ("Data *", self.ac_date),
                              ("Responsável", self.ac_person), ("Estado", self.ac_status),
                              ("Prazo", self.ac_deadline), ("Notas", self.ac_notes)):
            form.addRow(label, widget)
        layout.addLayout(form)
        button = QPushButton("Registar intervenção")
        button.clicked.connect(self.add_intervention)
        layout.addWidget(button)
        self.actions = QTableWidget(0, 5)
        self.actions.setHorizontalHeaderLabels(["Data", "Tipo", "Responsável", "Estado", "Prazo"])
        self.actions.setSelectionBehavior(QTableWidget.SelectRows)
        self.actions.setEditTriggers(QTableWidget.NoEditTriggers)
        self.actions.cellClicked.connect(self.show_action_detail)
        layout.addWidget(self.actions)
        self.action_detail = QLabel("Selecione uma intervenção para ver as notas.")
        self.action_detail.setWordWrap(True)
        layout.addWidget(self.action_detail)
        status_row = QHBoxLayout()
        self.change_status = QComboBox()
        self.change_status.addItems(STATUSES)
        status_row.addWidget(self.change_status)
        update = QPushButton("Alterar estado da intervenção selecionada")
        update.clicked.connect(self.update_action)
        status_row.addWidget(update)
        layout.addLayout(status_row)
        self.tabs.addTab(tab, "Intervenções")

    def _build_tasks_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(QLabel("Intervenções planeadas ou em curso; a vermelho, prazos vencidos."))
        self.tasks = QTableWidget(0, 5)
        self.tasks.setHorizontalHeaderLabels(["Prazo", "Árvore", "Tipo", "Estado", "Responsável"])
        self.tasks.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.tasks)
        self.tabs.addTab(tab, "Pendentes")

    def _mark_dirty(self, *args):
        if not self._loading:
            self.dirty = True

    def _discard_ok(self):
        if not self.dirty:
            return True
        return QMessageBox.question(
            self, "Alterações por guardar", "Descartar as alterações da ficha atual?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        ) == QMessageBox.Yes

    def _message(self, title, exc):
        QMessageBox.warning(self, title, str(exc))

    def create_file(self):
        if not self._discard_ok():
            return
        path, _ = QFileDialog.getSaveFileName(self, "Criar inventário", "arvoredo_urbano.gpkg",
                                              "GeoPackage (*.gpkg)")
        if not path:
            return
        if not path.lower().endswith(".gpkg"):
            path += ".gpkg"
        try:
            storage.create_inventory(path)
            self.load(path)
        except Exception as exc:
            self._message("Criar inventário", exc)

    def open_file(self):
        if not self._discard_ok():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Abrir inventário", "",
                                              "GeoPackage (*.gpkg)")
        if path:
            try:
                self.load(path)
            except Exception as exc:
                self._message("Abrir inventário", exc)

    def load(self, path):
        path = os.path.abspath(path)
        new_layer = storage.open_inventory(path)
        project = QgsProject.instance()
        old_layer = self.layer
        if old_layer is not None:
            try:
                old_layer.selectionChanged.disconnect(self.on_map_selection)
            except (TypeError, RuntimeError):
                pass
        existing = next((x for x in project.mapLayers().values()
                         if x.isValid() and x.source() == new_layer.source()), None)
        self.layer = existing or new_layer
        if existing is None:
            self._style_layer(self.layer)
            project.addMapLayer(self.layer)
        self.layer.selectionChanged.connect(self.on_map_selection)
        self.path = path
        project.writeEntry("ArvoredoUrbano", "inventario", path)
        self.file_label.setText(path)
        self._clear_form()
        self.refresh_list()
        self.refresh_tasks()

    @staticmethod
    def _style_layer(layer):
        colors = {"Não avaliado": "#86909c", "Baixo": "#2e8b57",
                  "Moderado": "#edb43b", "Alto": "#e76f35", "Urgente": "#c62d35"}
        categories = []
        for value, color in colors.items():
            symbol = QgsMarkerSymbol.createSimple({"name": "circle", "color": color,
                                                    "outline_color": "#303744", "size": "3.2"})
            categories.append(QgsRendererCategory(value, symbol, value))
        layer.setRenderer(QgsCategorizedSymbolRenderer("risco", categories))
        layer.triggerRepaint()

    def refresh_list(self, *args):
        self.tree_table.setRowCount(0)
        if self.layer is None:
            return
        query = self.search.text().strip().casefold()
        risk = self.risk_filter.currentText()
        count = 0
        for feature in self.layer.getFeatures():
            if risk != "Todos os riscos" and field_text(feature, "risco") != risk:
                continue
            values = [field_text(feature, name) for name in
                      ("codigo", "especie_comum", "freguesia", "estado", "risco")]
            haystack = " ".join(values + [field_text(feature, "especie_cientifica"),
                                           field_text(feature, "local")]).casefold()
            if query not in haystack:
                continue
            row = self.tree_table.rowCount()
            self.tree_table.insertRow(row)
            for col, value in enumerate(values):
                item = cell(value)
                if col == 0:
                    item.setData(Qt.UserRole, feature.id())
                self.tree_table.setItem(row, col, item)
            count += 1
        self.count_label.setText(f"{count} árvores (filtro atual)")
        self.tree_table.resizeColumnsToContents()

    def choose_row(self, row, _col):
        fid = self.tree_table.item(row, 0).data(Qt.UserRole)
        if fid != self.current_fid and not self._discard_ok():
            return
        self.select_feature(fid)

    def select_feature(self, fid):
        if self.layer is None:
            return
        feature = self.layer.getFeature(fid)
        if not feature.isValid():
            self.refresh_list()
            return
        self.current_fid = fid
        self.pending_point = None
        self._loading = True
        try:
            for name, widget in self.tree_fields.items():
                value = field_text(feature, name)
                if isinstance(widget, QComboBox):
                    widget.setCurrentText(value if value else widget.itemText(0))
                else:
                    widget.setText(value)
            self.notes.setPlainText(field_text(feature, "observacoes"))
            self.active.setChecked(field_text(feature, "ativo") != "0")
        finally:
            self._loading = False
        self.dirty = False
        self.position_label.setText("Árvore selecionada: " + field_text(feature, "codigo"))
        self.refresh_history()
        self.tabs.setCurrentIndex(0)
        self.layer.selectByIds([fid])
        self.plugin.iface.mapCanvas().setExtent(feature.geometry().boundingBox().buffered(15))
        self.plugin.iface.mapCanvas().refresh()

    def on_map_selection(self, selected, *args):
        if not selected or self.layer is None:
            return
        fid = next(iter(selected))
        if fid == self.current_fid:
            return
        if not self._discard_ok():
            if self.current_fid is not None:
                self.layer.selectByIds([self.current_fid])
            return
        self.select_feature(fid)

    def _clear_form(self):
        self._loading = True
        try:
            for widget in self.tree_fields.values():
                if isinstance(widget, QComboBox):
                    widget.setCurrentIndex(0)
                else:
                    widget.clear()
            self.notes.clear()
            self.active.setChecked(True)
        finally:
            self._loading = False
        self.current_fid = None
        self.pending_point = None
        self.dirty = False
        self.inspections.setRowCount(0)
        self.actions.setRowCount(0)
        self.inspection_detail.clear()
        self.action_detail.clear()

    def _map_tool(self, mode):
        self.plugin.start_map_tool(mode)
        self.position_label.setText("Clique no mapa para indicar a localização.")
        self.tabs.setCurrentIndex(0)

    def new_tree(self):
        if self.layer is None:
            self._message("Nova árvore", "Abra ou crie primeiro um inventário.")
            return
        if not self._discard_ok():
            return
        self._clear_form()
        existing = {field_text(f, "codigo").casefold() for f in self.layer.getFeatures()}
        number = self.layer.featureCount() + 1
        while f"AU-{number:05d}".casefold() in existing:
            number += 1
        self._loading = True
        self.tree_fields["codigo"].setText(f"AU-{number:05d}")
        self._loading = False
        self._map_tool("new")

    def move_tree(self):
        if self.current_fid is None:
            self._message("Mover árvore", "Selecione uma árvore.")
            return
        self._map_tool("move")

    def set_point(self, point, mode):
        if self.layer is None:
            return
        try:
            transform = QgsCoordinateTransform(
                self.plugin.iface.mapCanvas().mapSettings().destinationCrs(),
                self.layer.crs(), QgsProject.instance()
            )
            self.pending_point = transform.transform(point)
            self.dirty = True
            self.position_label.setText(
                f"Ponto marcado: {self.pending_point.x():.2f}, {self.pending_point.y():.2f} "
                "(EPSG:3763). Guarde a ficha."
            )
        except Exception as exc:
            self._message("Localização", exc)

    def _values(self):
        result = {}
        for name, widget in self.tree_fields.items():
            result[name] = widget.currentText() if isinstance(widget, QComboBox) else widget.text().strip()
        for name in ("altura_m", "dap_cm", "diametro_copa_m"):
            value = result[name].replace(",", ".")
            if value:
                try:
                    number = float(value)
                except ValueError as exc:
                    raise ValueError("As medidas têm de ser numéricas.") from exc
                if number < 0 or number > 10000:
                    raise ValueError("Verifique as medidas: devem estar entre 0 e 10 000.")
                result[name] = number
            else:
                result[name] = None
        for name in ("data_plantacao", "proxima_inspecao"):
            result[name] = storage.iso_date(result[name])
        result["observacoes"] = self.notes.toPlainText().strip()
        result["ativo"] = int(self.active.isChecked())
        return result

    def save(self):
        if self.layer is None:
            return
        try:
            feature = storage.save_tree(self.layer, self._values(), self.pending_point,
                                        self.current_fid)
            self.pending_point = None
            self.dirty = False
            self.refresh_list()
            self.select_feature(feature.id())
            self.refresh_tasks()
        except Exception as exc:
            self._message("Guardar ficha", exc)

    def _selected_feature(self):
        if self.layer is None or self.current_fid is None:
            raise ValueError("Selecione e guarde primeiro uma árvore.")
        feature = self.layer.getFeature(self.current_fid)
        if not feature.isValid():
            raise ValueError("A árvore selecionada deixou de existir.")
        return feature

    def add_inspection(self):
        try:
            feature = self._selected_feature()
            storage.add_inspection(self.path, self.layer, feature, {
                "data": self.in_date.text(), "tecnico": self.in_tech.text(),
                "estado": self.in_state.currentText(), "risco": self.in_risk.currentText(),
                "defeitos": self.in_defects.toPlainText(),
                "recomendacoes": self.in_recommend.toPlainText(),
                "proxima_inspecao": self.in_next.text(),
            })
            self.in_defects.clear()
            self.in_recommend.clear()
            self.refresh_list()
            # Uma inspeção atualiza apenas os campos de síntese da ficha.
            if not self.dirty:
                self.select_feature(self.current_fid)
            self.refresh_history()
        except Exception as exc:
            self._message("Registar inspeção", exc)

    def add_intervention(self):
        try:
            feature = self._selected_feature()
            storage.add_intervention(self.path, field_text(feature, "uuid"), {
                "tipo": self.ac_type.currentText(), "data": self.ac_date.text(),
                "responsavel": self.ac_person.text(), "estado": self.ac_status.currentText(),
                "prazo": self.ac_deadline.text(), "notas": self.ac_notes.toPlainText(),
            })
            self.ac_notes.clear()
            self.refresh_history()
            self.refresh_tasks()
        except Exception as exc:
            self._message("Registar intervenção", exc)

    def refresh_history(self):
        if self.current_fid is None or self.layer is None:
            return
        feature = self.layer.getFeature(self.current_fid)
        if not feature.isValid():
            return
        tree_uuid = field_text(feature, "uuid")
        self.inspection_records = storage.records(self.path, "au_inspecoes", tree_uuid)
        self.action_records = storage.records(self.path, "au_intervencoes", tree_uuid)
        self.inspections.setRowCount(0)
        self.inspection_detail.clear()
        for record in self.inspection_records:
            row = self.inspections.rowCount()
            self.inspections.insertRow(row)
            for col, name in enumerate(("data", "tecnico", "estado", "risco")):
                self.inspections.setItem(row, col, cell(record[name]))
        self.actions.setRowCount(0)
        self.action_detail.clear()
        for record in self.action_records:
            row = self.actions.rowCount()
            self.actions.insertRow(row)
            for col, name in enumerate(("data", "tipo", "responsavel", "estado", "prazo")):
                item = cell(record[name])
                if col == 0:
                    item.setData(Qt.UserRole, record["id"])
                self.actions.setItem(row, col, item)

    def show_inspection_detail(self, row, _col):
        record = self.inspection_records[row]
        self.inspection_detail.setText(
            "Defeitos: " + (record["defeitos"] or "—") + "\n"
            "Recomendações: " + (record["recomendacoes"] or "—") + "\n"
            "Próxima inspeção: " + (record["proxima_inspecao"] or "—")
        )

    def show_action_detail(self, row, _col):
        record = self.action_records[row]
        self.action_detail.setText("Notas: " + (record["notas"] or "—"))

    def update_action(self):
        try:
            feature = self._selected_feature()
            row = self.actions.currentRow()
            if row < 0:
                raise ValueError("Selecione uma intervenção na lista.")
            record_id = self.actions.item(row, 0).data(Qt.UserRole)
            storage.update_intervention(self.path, record_id, field_text(feature, "uuid"),
                                        self.change_status.currentText())
            self.refresh_history()
            self.refresh_tasks()
        except Exception as exc:
            self._message("Alterar estado", exc)

    def refresh_tasks(self):
        self.tasks.setRowCount(0)
        if self.layer is None:
            return
        labels = {field_text(f, "uuid"): field_text(f, "codigo")
                  for f in self.layer.getFeatures()}
        rows = storage.pending_interventions(self.path)
        today = date.today().isoformat()
        for record in rows:
            row = self.tasks.rowCount()
            self.tasks.insertRow(row)
            values = (record["prazo"], labels.get(record["arvore_uuid"], "[árvore indisponível]"),
                      record["tipo"], record["estado"], record["responsavel"])
            for col, value in enumerate(values):
                item = cell(value)
                if record["prazo"] and record["prazo"] < today:
                    item.setForeground(QColor("#b72229"))
                self.tasks.setItem(row, col, item)

    def export(self):
        if self.layer is None:
            self._message("Exportar", "Abra primeiro um inventário.")
            return
        directory = QFileDialog.getExistingDirectory(self, "Pasta para os três ficheiros CSV")
        if not directory:
            return
        if any(os.path.exists(os.path.join(directory, name + ".csv")) for name in
               ("arvores", "inspecoes", "intervencoes")):
            answer = QMessageBox.question(self, "Substituir CSV",
                "Já existem ficheiros CSV com estes nomes. Substituir?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                return
        try:
            storage.export_csv(self.path, self.layer, directory)
            QMessageBox.information(self, "Exportação concluída",
                "Foram criados arvores.csv, inspecoes.csv e intervencoes.csv.")
        except Exception as exc:
            self._message("Exportar", exc)


class ArvoredoUrbanoPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.action = None
        self.map_tool = None
        self.previous_tool = None

    def initGui(self):
        self.action = QAction(QIcon(os.path.join(os.path.dirname(__file__), "icon.svg")),
                              "Arvoredo urbano", self.iface.mainWindow())
        self.action.setObjectName("ArvoredoUrbanoAction")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToVectorMenu("Arvoredo urbano", self.action)
        self.iface.addToolBarIcon(self.action)

    def run(self):
        if self.dock is None:
            self.dock = ArvoredoDock(self)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
            saved = QgsProject.instance().readEntry("ArvoredoUrbano", "inventario", "")[0]
            if saved and os.path.isfile(saved):
                try:
                    self.dock.load(saved)
                except Exception as exc:
                    self.dock._message("Abrir inventário", exc)
        self.dock.show()
        self.dock.raise_()

    def start_map_tool(self, mode):
        canvas = self.iface.mapCanvas()
        if self.map_tool is None:
            self.map_tool = QgsMapToolEmitPoint(canvas)
        if canvas.mapTool() is not self.map_tool:
            self.previous_tool = canvas.mapTool()
        try:
            self.map_tool.canvasClicked.disconnect()
        except (TypeError, RuntimeError):
            pass
        self.map_tool.canvasClicked.connect(lambda point, button: self._map_click(point, button, mode))
        canvas.setMapTool(self.map_tool)

    def _map_click(self, point, button, mode):
        if button == Qt.LeftButton and self.dock is not None:
            self.dock.set_point(point, mode)
            if self.previous_tool is not None:
                self.iface.mapCanvas().setMapTool(self.previous_tool)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginVectorMenu("Arvoredo urbano", self.action)
            self.iface.removeToolBarIcon(self.action)
        if self.dock is not None:
            if self.dock.layer is not None:
                try:
                    self.dock.layer.selectionChanged.disconnect(self.dock.on_map_selection)
                except (TypeError, RuntimeError):
                    pass
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        if self.map_tool is not None and self.iface.mapCanvas().mapTool() is self.map_tool:
            if self.previous_tool is not None:
                self.iface.mapCanvas().setMapTool(self.previous_tool)
